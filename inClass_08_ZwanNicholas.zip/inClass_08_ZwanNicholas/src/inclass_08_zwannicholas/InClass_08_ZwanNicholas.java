/*
*Nicholas A. Zwan
*02/07/19
*This program was debugged and now allows for user input to calculate a price 
*of party expenses per guest.
*/
package inclass_08_zwannicholas;
import java.util.Scanner;
public class InClass_08_ZwanNicholas 
{
   public static void main(String[] args) {
   {
      final double GUEST_PRICE = 35.00;
      double price;
      double tax = 0.07;
      int guests;
      Scanner input = new Scanner(System.in);
      System.out.print("Enter number of guests >> ");
      guests = input.nextInt();
      System.out.println("***************************************************");
      System.out.println("*                                                 *");
      System.out.println("*  Jim's food makes the party great.              *");
      System.out.println("*                                                 *");
      System.out.println("***************************************************");
      price = guests * GUEST_PRICE;
      System.out.println("The final price after tax for an event with " + guests 
              + " guests at $" + GUEST_PRICE + " per guest is $" + (price * tax 
                      + (price)));
             
                     
   }
           
}
}   

