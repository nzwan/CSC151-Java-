
/*
 * Nicholas A. Zwan
 * 01/17/19
 * This program will accept user input and display it
 */
package inclass_04_zwannicholas;

import java.util.Scanner; //Needed for scanner class



public class InClass_04_ZwanNicholas {

    public static void main(String[] args) {
    
    String name;    // To hold users name
    int age;        // To hold users age
    double income;  // To hold users income
    
    // Create scanner object to read input
    Scanner keyboard = new Scanner(System.in);
    
    // Get the users age
    System.out.print("What is your age? ");
    age = keyboard.nextInt();
    
    //Get the users income
    System.out.print("What is your annual income? ");
    income = keyboard.nextDouble();
    
    // Consume the remaining newline
    keyboard.nextLine();
    
    // Get the users name
    System.out.print("What is your name? ");
    name = keyboard.nextLine();
    
    System.out.println("Hello, " + name +". Your age is " +
                       age + " and your income is $" + 
                       income);
    
 
    }
  
    
    
    
    
}
