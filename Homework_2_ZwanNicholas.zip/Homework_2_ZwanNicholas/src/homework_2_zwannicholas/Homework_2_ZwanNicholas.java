
package homework_2_zwannicholas;

/**
 *Nicholas A. Zwan
 * 02/26/19
 * This program uses an if statement to calculate and display pay details. 
 */
import javax.swing.JOptionPane;
public class Homework_2_ZwanNicholas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double Monday ;
        double Tuesday;
        double Wednesday;
        double Thursday;
        double Friday;
        double Saturday;
        double Sunday;
        double doubleTime = 2;
        double overTime = 1.5; 
        double totalPay1;
        double totalPay2;
        double totalPay3;
        double totalPay4;
        double totalPay5;
        double totalPay6;
        double totalPay7;
                
        
        String returnHours = "The number of hours worked ";
        double payRate;
        
        String inputString;
        
        
         
        inputString = 
                JOptionPane.showInputDialog("What is your pay rate?");
                payRate = Double.parseDouble(inputString);
        
       
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Monday?");
        Monday = Double.parseDouble(inputString);
        if (Monday > 10)
        {
           totalPay1 = (payRate * doubleTime) * (Monday - 8) + (Monday * payRate);    
        }
        
        else if (Monday > 8)
                {
                 totalPay1 = (payRate * overTime) * (Monday - 8) + (Monday * payRate);   
                }
        else
        {
            totalPay1 = payRate * Monday;
        }
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Tuesday?");
        Tuesday = Double.parseDouble(inputString);
         if (Tuesday > 10)
        {
           totalPay2 = (payRate * doubleTime) * (Tuesday - 8) + (Tuesday * payRate);    
        }
        
        else if (Tuesday > 8)
                {
                 totalPay2 = (payRate * overTime) * (Tuesday - 8) + (Tuesday * payRate);   
                }
        else
        {
            totalPay2 = payRate * Tuesday;
        }
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Wednesday?");
        Wednesday = Double.parseDouble(inputString);
        
         if (Wednesday > 10)
        {
           totalPay3 = (payRate * doubleTime) * (Wednesday - 8) + (Wednesday * payRate);    
        }
        
        else if (Wednesday > 8)
                {
                 totalPay3 = (payRate * overTime) * (Wednesday - 8) + (Wednesday * payRate);   
                }
        else
        {
            totalPay3 = payRate * Wednesday;
        }
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Thursday?");
        Thursday = Double.parseDouble(inputString);
        
         if (Thursday > 10)
        {
           totalPay4 = (payRate * doubleTime) * (Thursday- 8) + (Thursday * payRate);    
        }
        
        else if (Thursday > 8)
                {
                 totalPay4 = (payRate * overTime) * (Thursday - 8) + (Thursday * payRate);   
                }
        else
        {
            totalPay4 = payRate * Thursday;
        }
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Friday?");
        Friday = Double.parseDouble(inputString);
        
         if (Friday > 10)
        {
           totalPay5 = (payRate * doubleTime) * (Friday - 8) + (Friday * payRate);    
        }
        
        else if (Friday > 8)
                {
                 totalPay5 = (payRate * overTime) * (Friday - 8) + (Friday * payRate);   
                }
        else
        {
            totalPay5 = payRate * Friday;
        }
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Saturday?");
       Saturday = Double.parseDouble(inputString);
        if (Saturday > 10)
        {
           totalPay6 = (payRate * doubleTime) * (Saturday - 8) + (Saturday * payRate);    
        }
        
        else if (Saturday > 8)
                {
                 totalPay6 = (payRate * overTime) * (Saturday - 8) + (Saturday * payRate);   
                }
        else
        {
            totalPay6 = payRate * Saturday;
        }
       
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Sunday?");
        Sunday = Double.parseDouble(inputString);
        
         if (Sunday > 10)
        {
           totalPay7 = (payRate * doubleTime) * (Sunday - 8) + (Sunday * payRate);    
        }
        
        else if (Monday > 8)
                {
                 totalPay7 = (payRate * overTime) * (Sunday - 8) + (Sunday * payRate);   
                }
        else
        {
            totalPay7 = payRate * Sunday;
        }
        
        
        
        
        
        
            
        
        
        double totalHours = Monday + Tuesday + Wednesday + Thursday + Friday +
                Saturday + Sunday;
        
        double grossPay = totalPay1 + totalPay2 + totalPay3 + totalPay4 + totalPay5 +
                totalPay6 + totalPay7;
        
        
        
        double federalTax = grossPay * 0.1475;
        double stateTax = grossPay * 0.0425;
        double socialSecurity = grossPay * 0.0645;
        double medicare = grossPay * 0.0189;
        double taxesOwed = (federalTax + stateTax + socialSecurity + medicare);
        
       double netPay = grossPay - taxesOwed;
       
        
        JOptionPane.showMessageDialog(null, returnHours + "Monday " + Monday + "\n" +
             returnHours + "Tuesday " + Tuesday + "\n" + returnHours + "Wednesday " + Wednesday + 
                "\n" + returnHours + "Thursday " + Thursday + "\n" + returnHours + "Friday " 
                + Friday + "\n" + returnHours + "Saturday " + Saturday + "\n" +
                returnHours + "Sunday " + Sunday + "\n" +
                 "The total number of hours worked is " +  totalHours + "\n" +
                "Your gross pay is $" + grossPay + "The federal Taxes owed: $" + federalTax +
                "\n" + "The state taxe owed: $" + stateTax + "\n" + "The social security owed: $" 
                + socialSecurity + "The medicare owed: $" + medicare + "\n" +
                "The total amount of taxes owed: $" + taxesOwed + "\n" + "Your netpay is $"
                + netPay);
        
        
        
        
        
        
        
    }
    
}
