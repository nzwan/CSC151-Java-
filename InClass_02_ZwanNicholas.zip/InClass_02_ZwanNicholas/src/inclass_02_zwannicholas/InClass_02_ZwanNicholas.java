/**
 *Nicholas Zwan
 * 01/17/19
 * This program calculates gross pay.
 * This is my first in class program exercise.
 */
package inclass_02_zwannicholas;
public class InClass_02_ZwanNicholas {
    public static void main(String[] args) 
    {
    int hours = 40;
    double grossPay, payRate = 25.0;
    
    grossPay = hours * payRate;
    System.out.println("Your gross pay is $" + grossPay);
    }
    
}
