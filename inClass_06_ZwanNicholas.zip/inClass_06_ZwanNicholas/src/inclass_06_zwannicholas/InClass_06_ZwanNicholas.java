/*
 * Nicholas A. Zwan
 * 01/31/19
 * This program demonstrates using dialogs with JOptionPane.
 */
package inclass_06_zwannicholas;
import javax.swing.JOptionPane;


public class InClass_06_ZwanNicholas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String inputString; //For reading input
        String name;        //The users name
        int hours;          //The number of hours worked
        double payRate;     //The users hourly pay rate
        double grossPay;    //The users gross pay
        
        //Get the users name
        name = JOptionPane.showInputDialog("What is your name? ");
        
        //Get the hours worked
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work? " 
                        + "This week ");
        
        //Convert Input to an int
        hours = Integer.parseInt(inputString);
        
        //Get the hourky rate
        inputString = 
                JOptionPane.showInputDialog("What is your hourly pay rate? ");
        
        //convert input to a double
        payRate = Double.parseDouble(inputString);
        
        //Calculate the gross pay.
        grossPay = hours * payRate;
        
        //Display the results.
        JOptionPane.showMessageDialog(null, "Hello " +
                name + ". Your gross pay is $" +
                grossPay);
        
        //End the program.
        System.exit(0);
    }
    
}
