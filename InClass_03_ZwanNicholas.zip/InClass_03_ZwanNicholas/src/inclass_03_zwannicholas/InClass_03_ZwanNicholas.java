package inclass_03_zwannicholas;
/**
 *Nicholas Zwan
 * 01/17/19
 * This program calculates gross pay with user input.
 * This is my second in class program exercise.
 */
import java.util.Scanner; //Needed for scanner class


public class InClass_03_ZwanNicholas 
{
    public static void main(String[] args) 
    {
        String name;        // To hold a name
        int hours;          // Hours worked
        double payRate;     // Hourly pay rate
        double grossPay;     // Gross pay
        
        // Create a Scanner object to read input
        Scanner keyboard = new Scanner(System.in);
        
        //Get the users name
        System.out.print("What is your name? ");
        name = keyboard.nextLine();
        
        // Get the number of hours worked this week
        System.out.print("How many hours did you work this week? ");
        hours = keyboard.nextInt();
        
        // Get the users hourly pay rate
        System.out.print("What is your hourly payrate? ");
        payRate = keyboard.nextDouble();
        
        // Calculate gross pay
        grossPay = hours * payRate;
       
        // Display the resulting information
        System.out.println("Hello, " + name);
        System.out.println("Your gross pay is $" + grossPay);
       
                
                
    }
    
}

