/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inclass_29_zwannicholas;

/**
 *
 * @author zwann3612
 */
public class Device {
    private String manufact; //Manufacturer
    private String model; //model
    private double retailPrice; //Retail price
    private String deviceColor; //device color
    private String deviceType; //device type
    
    /**
    *@param man The devices manufacturer.
    *@param mod The devices model number. 
    *@param price The devices retail price.
    *@param type The devices type.
    *@param color The devices color.
    */
    
    public Device(String man, String mod, double price, String type, String color)
    {
        
        manufact = man;
        model = mod;
        retailPrice = price;
        deviceType = type;
        deviceColor = color;
        
        
    }
    /**
      The setManufact method sets the phones manufacturer name
      @param man The phones manufacturer.
     */
    public void setManufact(String man)
    {
        manufact = man;
    }
    /**
     The set model method sets the phones model number
     @param mod The phones model number
     */
    public void setMod(String mod)
    {
        model = mod;
    }
    /**
      The setRetailPrice method sets the phones retail price.
     @param price The retail price.
     */
    public void setRetailPrice(double price)
    {
        retailPrice = price;
    }
    /**
    getManufact method
    @return The name of the phones manufacturer.
    */
    
    public String getManufact()
    {
        return manufact;
    }
    
    /** 
     getModel method.
     @return The phones model.
     */
    
    public String getModel()
    {
        return model;
    }
    
    /** 
     * getRetailPrice method
     * @return The phones retail price
     */
    
    public double getRetailPrice()
    {
        return retailPrice;
    }
    /**
      The setManufact method sets the phones manufacturer name
      @param type The devices type.
     */
    public void setType(String type)
    {
        deviceType = type;
    }
    /**
     The set model method sets the phones model number
     @param color The phones model number
     */
    public void setColor(String color)
    {
        deviceColor = color ;
    }
     
    /**
    getType method
    @return The name of the devices type;
    */
    public String getType()
    {
        return deviceType;
    }
    
    /** 
     getColor method.
     @return The devices color.
     */
    
    public String getColor()
    {
        return deviceColor;
    }
}
    

