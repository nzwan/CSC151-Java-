
package inclass_29_zwannicholas;
import java.util.Scanner;
/**
 * Nicholas A.Zwan
 * 05/02/19
 * InClass 29
 * This program demos classes and constructors
 */
public class InClass_29_ZwanNicholas {
    
    

    public static void main(String[] args) {
        hello();
        getDevice();
        goodbye();
    }
    public static void hello()
    {
        System.out.println("Hello there!");
    }
    public static void goodbye()
    {
        System.out.println("Goodbye old friend, and may the force be with you.");
    }
    
    public static void getDevice()
    {
         String testMan; // To hold a manufacturer
        String testMod; // To hold a model number
        double testPrice; // To hold a price
        String testColor; //To hold color
        String testType; //To hold type
       
        
        
        //Create scanner object
        Scanner keyboard = new Scanner(System.in);
        
         //Get Device type name
        System.out.print("Enter the device type >");
        testType = keyboard.nextLine();
        
        //Get Manufacturer name
        System.out.print("Enter the manufacturer name >");
        testMan = keyboard.nextLine();
        
        //Get Model number
        System.out.print("Enter the Model number >");
        testMod = keyboard.nextLine();
        
        //Get the color
        System.out.print("Enter the device color >");
        testColor = keyboard.nextLine();
        
        //Get Retail Price
        System.out.print("Enter the retail price >");
        testPrice = keyboard.nextDouble();
        
        while (testPrice > 0)
        {
        //Create an instance of the cell phone class,
        //Passing data that was entered as arguments
        //to the constructor.
        Device device = new Device(testMan, testMod, testPrice, testType, testColor);
        
        //Get data from the phone and display it
        
        System.out.println();
        System.out.println("Here is the data that you provided;");
        System.out.println("Manufacturer: " + device.getManufact());
        System.out.println("Model Number: " + device.getModel());
        System.out.println("Retail Price: " + device.getRetailPrice());
        System.out.println("Device Color: " + device.getColor());
        System.out.println("Device Type:  " + device.getType());
    
        
        break;
        
    }
        while (testPrice <= 0)
        {
            System.out.println("Please enter a number greater than 0");
           
            getDevice();
         
        }
    }
}

    

