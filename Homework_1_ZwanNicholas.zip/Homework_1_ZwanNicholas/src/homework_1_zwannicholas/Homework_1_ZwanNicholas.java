/*
 * Nicholas A. Zwan
 * 02/19/19
 * Homework 1
 * This program will accept input from user and do 
 * various calculatons on stock transactions 
 */
package homework_1_zwannicholas;

//Import JOptionPane
import javax.swing.JOptionPane;

public class Homework_1_ZwanNicholas {

    
    public static void main(String[] args) {
        //Create Variables
        double Amtpaid;  
        double fee;
        int num_shares;
        
        String inputString; //Accepts input from user.
        
        inputString = 
                JOptionPane.showInputDialog("How many shares did you purchase?");
        num_shares =Integer.parseInt(inputString);
        
        inputString = 
                JOptionPane.showInputDialog("How much did you pay per share?");
        Amtpaid = Double.parseDouble(inputString);
        
        double subtotal = Amtpaid * num_shares;
        double purchase_fee = subtotal *0.02; 
       
        
        
        
        double percent_sold;
        double sale_amount;
        
        
        
        inputString = 
                JOptionPane.showInputDialog("How much of your shares did you sell?");
        percent_sold = Double.parseDouble(inputString);
        
        double shares_sold = percent_sold * num_shares;
        
        inputString = 
                JOptionPane.showInputDialog("How much did you sell each share for?");
        sale_amount = Double.parseDouble(inputString);
        
        double sale_fee = shares_sold * 0.02;
        double stock_remaining = num_shares - shares_sold;
        double num_profit = (shares_sold * sale_amount) - sale_fee;
        
        JOptionPane.showMessageDialog(null, "You paid $" + subtotal + " for your stock. " + "\n" +
        "Your total fee was $" + purchase_fee + "\n" +
        "You own " + num_shares + " The value of which is $" + subtotal + "\n" +
                "You sold " + shares_sold + " of your stock." + "for $" + sale_amount + "\n" 
                + "and paid a fee of $" + sale_fee + "for a total profit of $" + 
                num_profit + "\n" + "You have " + stock_remaining + " shares left.");
        
        
        
     
    }
    
}
