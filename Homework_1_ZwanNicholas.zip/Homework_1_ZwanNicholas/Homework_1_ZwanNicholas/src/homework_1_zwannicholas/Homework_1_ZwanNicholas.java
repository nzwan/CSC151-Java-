/*
 * Nicholas A. Zwan
 * 02/19/19
 * Homework 1
 * This program will accept input from user and do 
 * various calculatons on stock transactions 
 */
package homework_1_zwannicholas;

//Import JOptionPane
import javax.swing.JOptionPane;

public class Homework_1_ZwanNicholas {

    
    public static void main(String[] args) 
    {
        //Create Variables
        double Amtpaid;  
        
        int num_shares;
        
        String choice;
        String choice1 = "percentage"; 
        String choice2 = "number";
        
        
 
        
        
        String inputString; //Accepts input from user. Display input box.
        
        inputString = 
                JOptionPane.showInputDialog("Do you want to calculate by percentage"
                        + "or number of shares?");
        choice = (inputString);
        
        if (choice == "percentage")
        {
        inputString = 
                JOptionPane.showInputDialog("How many shares did you purchase?");
        num_shares =Integer.parseInt(inputString);
        if (num_shares < 0);
        {
        JOptionPane.showMessageDialog(null,"Bad value! Please try again");
        
        
        
            
        
        while (num_shares > 0)
        {
        inputString = 
                JOptionPane.showInputDialog("How much did you pay per share?");
        Amtpaid = Double.parseDouble(inputString);
        
        //Declare more variables
        double subtotal = Amtpaid * num_shares;
        double purchase_fee = subtotal * 0.02;
        double percent_sold;
        double sale_amount;
        
        //Accept input from user. Display input box.
        inputString = 
                JOptionPane.showInputDialog("What percentage of your shares did you sell? Enter a decimal");
        percent_sold = Double.parseDouble(inputString);
        //Yet another variable
        double shares_sold = percent_sold * num_shares;
        //Accept input from user. Display input box.
        inputString = 
                JOptionPane.showInputDialog("How much did you sell each share for?");
        sale_amount = Double.parseDouble(inputString);
        
        //Declare more variables.
        double stock_remaining = num_shares - shares_sold;
        double num_profit = (shares_sold * sale_amount);
        double sale_fee = num_profit * 0.02;
        double total_Profit = num_profit - sale_fee; 
       
        
        //Perform calculations and return results
        JOptionPane.showMessageDialog(null,
                ("You paid $" + subtotal + " for your stock. " + "\n" +
        "Your total fee was $" + purchase_fee + "\n" +
        "You own " + num_shares + " The value of which is $" + subtotal + "\n" +
                "You sold " + shares_sold + " of your stock" + " for $" +  sale_amount + "\n" 
                + "and paid a fee of $" + sale_fee + " for a total profit of $" + 
                total_Profit + "\n" + "You have " + stock_remaining + " shares left."));
        
        
        
       
        
        while (choice == choice2)
        {
         JOptionPane.showMessageDialog(null, "The total amount of shares sold"
                + "is " + shares_sold + " and the value is $" + total_Profit);
        
        }
        }
        }
        }
    }
}

        
        
        
        
        
    
        
        
        
    
        
        
        
        
        
        
        
               
        

        
        
        
        
        
        
        
        
    
     
        
    
