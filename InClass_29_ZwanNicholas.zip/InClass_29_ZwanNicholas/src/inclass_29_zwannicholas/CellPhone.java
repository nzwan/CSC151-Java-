
package inclass_29_zwannicholas;

/**
 * Nicholas A. Zwan
 * 05/01/19
 * Constructs a cell phone class. 
 */
public class CellPhone {
    // Fields 
    private String manufact; //Manufacturer
    private String model; //model
    private double retailPrice; //Retail price
    
    /**
    *@param man The phones manufacturer.
    *@param mod The phones model number. 
    *@param price The phones retail price.
    */
    
    public CellPhone(String man, String mod, double price)
    {
        manufact = man;
        model = mod;
        retailPrice = price;
        
    }
    /**
      The setManufact method sets the phones manufacturer name
      @param man The phones manufacturer.
     */
    public void setManufact(String man)
    {
        manufact = man;
    }
    /**
     The set model method sets the phones model number
     @param mod The phones model number
     */
    public void setMod(String mod)
    {
        model = mod;
    }
    /**
      The setRetailPrice method sets the phones retail price.
     @param price The retail price.
     */
    public void setRetailPrice(double price)
    {
        retailPrice = price;
    }
    /**
    getManufact method
    @return The name of the phones manufacturer.
    */
    
    public String getManufact()
    {
        return manufact;
    }
    
    /** 
     getModel method.
     @return The phones model.
     */
    
    public String getModel()
    {
        return model;
    }
    
    /** 
     * getRetailPrice method
     * @return The phones retail price
     */
    
    public double getRetailPrice()
    {
        return retailPrice;
    }
}

