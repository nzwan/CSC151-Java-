
package inclass_29_zwannicholas;
import java.util.Scanner;
/**
 * Nicholas A.Zwan
 * 05/02/19
 * InClass 29
 * This program demos classes and constructors
 */
public class InClass_29_ZwanNicholas {

    public static void main(String[] args) {
        String testMan; // To hold a manufacturer
        String testMod; // To hold a model number
        double testPrice; // To hold a price
        
        //Create scanner object
        Scanner keyboard = new Scanner(System.in);
        
        //Get Manufacturer name
        System.out.print("Enter the manufacturer name >");
        testMan = keyboard.nextLine();
        
        //Get Model name
        System.out.print("Enter the Model name >");
        testMod = keyboard.nextLine();
        
        //Get Retail Price
        System.out.print("Enter the retail price >");
        testPrice = keyboard.nextDouble();
        
        //Create an instance of the cell phone class,
        //Passing data that was entered as arguments
        //to the constructor.
        CellPhone phone = new CellPhone(testMan, testMod, testPrice);
        
        //Get data from the phone and display it
        System.out.println();
        System.out.println("Here is the dats that you provided;");
        System.out.println("Manufacturer: " + phone.getManufact());
        System.out.println("Model Number: " + phone.getModel());
        System.out.println("Retail Price: " + phone.getRetailPrice());
    }
    
}
