package inclass26_zwannicholas;

/**
 * Nicholas A. Zwan
 * CSC 151
 * 04/16/19
 * InClass26
 * This program will demo a simple method call and display corresponding 
 * messages.
 */
public class InClass26_ZwanNicholas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      System.out.println("Hello from the main method.");
      displayMessage();
      System.out.println("Back in the main method!");
      
      //Display simple greeting from a method
    }
    public static void displayMessage()
    {
       System.out.println("Hello from the display message method!");
    }
    
}
