/*
 * Nicholas A. Zwan
 * 02/12/19
 * This program demos different calculations and uses JOptionPane to display 
   results.
 */
package inclass_09_zwannicholas;

//Import JOptionPane
import javax.swing.JOptionPane;


public class InClass_09_ZwanNicholas {

    public static void main(String[] args) {
       int num1; //Creates variable num2
       int num2; //Creates variable num2
       String inputString; //Accepts input for user
       
      
       //User will enter value of num1
       inputString = 
               JOptionPane.showInputDialog("Enter a value for num1: ");
       
       num1 = Integer.parseInt(inputString);
       //User will input value of num2
       inputString = 
               JOptionPane.showInputDialog("Enter a value for num2: ");
       num2 = Integer.parseInt(inputString);
       
       
       //Generate formulas for calculations
       int addition = num1 + num2;
       int subtraction = num1 - num2;
       int multiplication = num1 * num2;
       int division = num1 / num2;
       int modulus = num1 % num2;
       
       
      //Display results
      JOptionPane.showMessageDialog(null,"When added together the two numbers amount to " + addition + "\n" +
              "When subtracted the two numbers amount to " + subtraction + "\n" + "When multiplied the two numbers amount to "
              + multiplication + "\n" + "When multiplied the two numbers amount to " + multiplication + "\n" +
              "When divided the two numbers amount to " + division + "\n" + "When seeking the modulus the two numbers will return " + modulus);
      
      System.exit(0);
              
       
    
      
       
       
       
    }
    
}
