
package homework_2_zwannicholas;

/**
 *Nicholas A. Zwan
 * 02/26/19
 * This program uses an if statement to calculate and display pay details. 
 */
import javax.swing.JOptionPane;
public class Homework_2_ZwanNicholas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double Monday ;
        double Tuesday;
        double Wednesday;
        double Thursday;
        double Friday;
        double Saturday;
        double Sunday;
        
        String returnHours = "The number of hours worked ";
        double payRate;
        
        String inputString;
        
        inputString = 
                JOptionPane.showInputDialog("What is your pay rate?");
        payRate = Double.parseDouble(inputString);
       
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Monday?");
        Monday = Double.parseDouble(inputString);
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Tuesday?");
        Tuesday = Double.parseDouble(inputString);
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Wednesday?");
        Wednesday = Double.parseDouble(inputString);
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Thursday?");
        Thursday = Double.parseDouble(inputString);
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Friday?");
        Friday = Double.parseDouble(inputString);
        
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Saturday?");
       Saturday = Double.parseDouble(inputString);
       
       inputString = 
                JOptionPane.showInputDialog("How many hours did you work on Sunday?");
        Sunday = Double.parseDouble(inputString);
        
        
        
        double totalHours = Monday + Tuesday + Wednesday + Thursday + Friday +
                Saturday + Sunday;
        
        double grossPay = payRate * totalHours;
        
        double federalTax = grossPay * 0.1475;
        double stateTax = grossPay * 0.0425;
        double socialSecurity = grossPay * 0.0645;
        double medicare = grossPay * 0.0189;
        double taxesOwed = (federalTax + stateTax + socialSecurity + medicare);
        
       double netPay = grossPay - taxesOwed;
       
        
        JOptionPane.showMessageDialog(null, returnHours + "Monday " + Monday + "\n" +
             returnHours + "Tuesday " + Tuesday + "\n" + returnHours + "Wednesday " + Wednesday + 
                "\n" + returnHours + "Thursday " + Thursday + "\n" + returnHours + "Friday " 
                + Friday + "\n" + returnHours + "Saturday " + Saturday + "\n" +
                returnHours + "Sunday " + Sunday + "\n" +
                 "The total number of hours worked is " +  totalHours + "\n" +
                "Your gross pay is $" + grossPay + "The federal Taxes owed: $" + federalTax +
                "\n" + "The state taxe owed: $" + stateTax + "\n" + "The social security owed: $" 
                + socialSecurity + "The medicare owed: $" + medicare + "\n" +
                "The total amount of taxes owed: $" + taxesOwed + "\n" + "Your netpay is $"
                + netPay);
        
        
        
        
        
        
        
    }
    
}
