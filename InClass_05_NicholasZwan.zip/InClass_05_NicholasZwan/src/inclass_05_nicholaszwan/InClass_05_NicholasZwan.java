/*
 * Nicholas A. Zwan
 * 01/29/1
 * This program accepts input and calculates the total price of a purchase. 
 */
package inclass_05_nicholaszwan;

import java.util.Scanner; //Needed for scanner class 


public class InClass_05_NicholasZwan {

    public static void main(String[] args) {
       String name; // To hold Cuatomer Name
       String itemPurchased; // To hold item name
       final double State_Tax_Rate = 0.04;  //Declares State Tax Variable
       final double County_Tax_Rate = 0.02; //Declares County Tax Variable
       double totalTax;    //Declares totalTax variable
       double totalPrice; //Declares totalPrice variable
        
        Double purchaseAmount; //To hold purchase amount
        
        //Creates a scanner object to read input
        Scanner keyboard = new Scanner(System.in);
        
        //Get the users name
        System.out.print("What is your name? ");
        name = keyboard.nextLine();
        
        //Gets the item name
        System.out.print("What did you purchase? ");
        itemPurchased = keyboard.nextLine();
                
        //Get the amount of the purchase
        System.out.print("What was the subtotal for the purchase? ");
        purchaseAmount = keyboard.nextDouble();
        
        //Calculares total tax amount
        totalTax = purchaseAmount * State_Tax_Rate + purchaseAmount * County_Tax_Rate;
        
        //Calculates total price
        totalPrice = purchaseAmount + totalTax; 
        
        //Display the resulting info
        System.out.println("Hello, " + name);
        System.out.println("You purchased " + itemPurchased);
        System.out.println("The subtotal for the transaction is $" + purchaseAmount);
        System.out.println("The total tax is $" + totalTax);
        System.out.println("The total amount of the transaction is $" + totalPrice);
        
        
        
        
        
        
        
        
        
                
    }
    
}
