/*
 * Nicholas A. Zwan
 * 02/05/19
 * This program demonstrates using dialogs with JOptionPane.
 */
package inclass_07_zwannicholas;
import javax.swing.JOptionPane;


public class InClass_07_ZwanNicholas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String inputString; //For reading input
        String name;        //The users name
        int hours = 0;          //The number of hours worked
        double payRate = 0.0;     //The users hourly pay rate
        double grossPay = 0.0;    //The users gross pay
        double fedTax = 0.0;      //users fed tax rate
        double stateTax = 0.0;    //users state tax rate  
        double socialSecurity = 0.0; //users social security rate
        double medicare = 0.0;       //users medicare rate
        double totalTaxes = 0.0;
        double netPay = 0.0;         //users netpay
        
        //Get the users name
        name = JOptionPane.showInputDialog("What is your name? ");
        
        //Get the hours worked
        inputString = 
                JOptionPane.showInputDialog("How many hours did you work? " 
                        + "This week ");
        
        //Convert Input to an int
        hours = Integer.parseInt(inputString);
        
        //Get the hourly rate
        inputString = 
                JOptionPane.showInputDialog("What is your hourly pay rate? ");
        
        //convert input to a double
        payRate = Double.parseDouble(inputString);
        
         inputString = 
                JOptionPane.showInputDialog("What is the federal Tax rate? ");
         
         fedTax = Double.parseDouble(inputString);
         
         inputString = 
                JOptionPane.showInputDialog("What is the state Tax rate? ");
         
         stateTax = Double.parseDouble(inputString);
         
         inputString = 
                JOptionPane.showInputDialog("What is the social security rate? ");
         
         socialSecurity = Double.parseDouble(inputString);
         
         inputString = 
                JOptionPane.showInputDialog("What is the medicare rate? ");
         
         medicare = Double.parseDouble(inputString);
         
        
        //Calculate the gross pay.
        grossPay = hours * payRate;
        
        
        //Display the results.
        JOptionPane.showMessageDialog(null, "Hello " +
                name + ". Your gross pay is $" +
                grossPay);
        
        //calculate the net pay
       totalTaxes = (grossPay * fedTax) + (grossPay * stateTax) + (grossPay * socialSecurity) +
                (grossPay * medicare);
       netPay = grossPay - totalTaxes;
        
         JOptionPane.showMessageDialog(null, "Hello " + name 
                 + ". Your net pay is $" + netPay);
        
        
        //End the program.
        System.exit(0);
    }
    
}