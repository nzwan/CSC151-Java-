package inclass_17_part2_zwannicholas;
import java.util.Scanner;

/**
 * Nicholas A. Zwan
 * InClass17
 * 03/14/19
 * This program demonstrates string comparisons using scanner and 
 * decision structures. 
 */
public class InClass_17_part2_ZwanNicholas {

  
    public static void main(String[] args) {
       String input; //To hold user input
       //String name1 = "Mark",
       //name2 = "Mark",
       //name3 = "Mary";
       
       Scanner keyboard = new Scanner(System.in);
       
       //Get names from the user.
       System.out.println("Enter a Name for name4: > ");
       input = keyboard.nextLine();
       String name4 = input;
       
       System.out.println("Enter a Name for name5: > ");
       input = keyboard.nextLine();
       String name5 = input;
      
       System.out.println("Enter a Name for name6: > ");
       input = keyboard.nextLine(); 
       String name6 = input;
       
       System.out.println("You entered the name " + name4);
       System.out.println("You entered the name " + name5);
       System.out.println("You entered the name " + name6);
       
       
       //Compare User Input name4 and name 5 
       if (name4.equals(name5))
       {
           System.out.println(name4+ " and " + name5 + " are the same.");
       }
       else
       {
           System.out.println(name4+ " and " + name5 + " are not the same.");
       }
       
       //Compate User Input name4 and name6
       if (name4.equals(name6))
       {
          System.out.println(name4+ " and " + name6 + " are the same."); 
       }
       else
       {
          System.out.println(name4+ " and " + name6+" are not the same.");
       }
       
       //Compare Mark and User input
       //if (name1.equals(name4))
       {
         // System.out.println(name1+ " and " + name4 + " are the same."); 
       }
       //else
       {
         // System.out.println(name1+ " and " + name4 +" are not the same.");
       }
       
       //Comapare Mary and User input
      // if (name3.equals(name4))
       {
        //  System.out.println(name3+ " and " + name4 + " are the same."); 
       }
       //else
       {
         // System.out.println(name3+ " and " + name4+" are not the same.");
       }
    }
    
    
    
}
