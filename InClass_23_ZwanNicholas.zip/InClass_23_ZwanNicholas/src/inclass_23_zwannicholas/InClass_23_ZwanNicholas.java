
package inclass_23_zwannicholas;

/**
 * Nicholas A Zwan
 * 04/04/19
 * In Class 23
 * This program demonstrates the switch statement.
 */
import java.util.Scanner;
public class InClass_23_ZwanNicholas {

    
    public static void main(String[] args) {
        
        String input;
        
        //Create a scanner to accept input
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("This program will translate an english "
                + "season name to the spanish.");
        
        //Get a day from the user
        System.out.print("Enter the name of the season: ");
        input = keyboard.nextLine();
        
        //Translate season to spanish
        switch(input)
        {
            case "spring":
                System.out.println("la primavera");
                break;
            case "summer":
                System.out.println("el verano");
                break;
            case "autumn":
            case "fall":
                System.out.println("el otono");
                break;
            case "winter":
                System.out.println("el invierno");
                break;
            default:
                System.out.println("Please enter a valid option! IE"
                        + "summer, spring, winter, fall or autumn. ");
        }
    }
    
}
