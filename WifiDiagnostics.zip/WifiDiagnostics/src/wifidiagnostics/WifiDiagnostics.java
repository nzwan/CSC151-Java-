
package wifidiagnostics;
import java.util.Scanner;
/**
 * Nicholas A. Zwan
 * Wifi Diagnostics
 * This program will walk the user through router troubleshooting.
 */
public class WifiDiagnostics {

    
    public static void main(String[] args) 
    {
        
        {
    String yes = "Yes",
           no = "No"; //Unused. For future development. 
    String input; //To hold user input
    
    
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("So your router is not working....");
    System.out.println("Concerning the questions that will be asked, "
            + "please"+ "\n" + "enter 'Yes' or 'No'. "
            + "Input is case sensitive anything that does "
            + "\n" + "not equal 'Yes' will be read as 'no'.");
    System.out.println("Reboot the computer and try to connect." + "\n"
    + "Did that work? > ");
    input = keyboard.nextLine();
    String answer = input;
    
    if (answer.equals(yes))
    {
        System.out.println("Great, your router is fixed!");
    }
    else 
    {
    System.out.println("Reboot the router and try to connect." + "\n"
    + "Did that work? > ");
    input = keyboard.nextLine();
    String answer2 = input;
    
    if (answer2.equals(yes))
    {
        System.out.println("Great, your router is fixed!");
    }
    else
    {
        System.out.println("Make sure the cables between your router"
                + "and modem are plugged in firmly. Did that work? > ");
        input = keyboard.nextLine();
        String answer3 = input;
        
        if (answer3.equals(yes))
        {
            System.out.println("Great, your router is fixed.");
        }
        else
        {
            System.out.println("Try moving the router to a new location."
                    + " Did that work? > ");
            input = keyboard.nextLine();
            String answer4 = input;
            if (answer4.equals(yes))
            {
                System.out.println("Great Your router is fixed!");
            }
            else
            {
                System.out.println("You better get a new router.");
            }
        }
    }
    
    
    
    
    }
    
        }
    }
}
