
package homework_4_zwann3612;

/**
 * Nicholas A. Zwan
 * Homework_4_zwann3612
 * This program demonstrates various operation using methods.
 */
import java.util.Scanner; //Needed for scanner class
import java.io.*; //Needed for file I/O classes
public class Homework_4_Zwann3612 {
    

    
    public static void main(String[] args) {
        greeting();
        ValueReturn();
        farewell();
        
        
    }
    public static void greeting()
    {
        System.out.println("Hello, User.");
    }
    public static void ValueReturn()
    {
        Scanner keyboard = new Scanner(System.in);
        int total, value1, value2;
        System.out.print("Enter a value for value1 >>");
        value1 = keyboard.nextInt();
      
        
        
        
        System.out.print("Enter a value for value2 >>");
        value2 = keyboard.nextInt();
        
        while (value1 <1 || value2 < 1)
        {
        System.out.println("Please enter a positive value");
        ValueReturn();
        break;
        }
        //Call the sum method, passing the contents of 
        //value1 and value2 as arguments. Assign the
        //return value to the total variable.
        total = sum(value1, value2);
        System.out.println("The sum of " + value1 + " and " + value2 + " is "
        + total);
        
        
        }
   

       
    
    public static int sum(int num1, int num2)
    {
        int result; // result is a local variable
        
        //assign the value of num1 + num2 to result
        result = num1 + num2;
        
        //Return the value in the result variable.
        return result;
    }            
    public static void farewell()
    {
        System.out.println("Goodbye, User.");
    }
    
}

//toDo add filewriting functionality.
