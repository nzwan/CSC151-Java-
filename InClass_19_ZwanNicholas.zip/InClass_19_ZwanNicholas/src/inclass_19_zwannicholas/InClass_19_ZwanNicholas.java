
package inclass_19_zwannicholas;

/**
 *Nicholas A. Zwan
 * 03/26/19
 * InClass19
 * This program writes data to a file.
 */
  import java.util.Scanner; //Needed for scanner class
  import java.io.*;         //Needed for file I/O classes
public class InClass_19_ZwanNicholas {
  
    public static void main(String[] args) throws IOException {
       String filename;     //File Name
       String friendName;   //Friends name
       int numFriends;      //Number of friends
       int Zero = 0;
       
       //Create scanner for input
       Scanner keyboard = new Scanner(System.in);
       
       //Get the number of friends
       System.out.print("How many friends do you have? >> ");
       numFriends = keyboard.nextInt();
       
         if (numFriends <= 0)
           {
               System.out.println("Not a valid choice");
           }
       else
         {
       
       while (numFriends > 0)
       {
           //Consume the remaining newline
           keyboard.nextLine();
           
           //Get the fileName 
           System.out.print("Enter the fileName >> ");
           filename = keyboard.nextLine();
           
           //Open the file
           PrintWriter outputFile = new PrintWriter(filename);
           
           //Get data and write it to the file
           for(int i = 1; i <= numFriends; i++)
           {
               // Get the name of a friend 
               System.out.println("Enter a friends name >> "
                       + "number" + i + ": ");
               friendName = keyboard.nextLine();
               
               //Write the name to the file.
               outputFile.println(friendName);
            
               
               
           }
              
             
          
              //Close the file
           outputFile.close();
           System.out.println("Data Written to the file.");
           
           
           
           
           
           
       }
               
    }
    
}
}
