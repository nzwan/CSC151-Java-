/*
 * Nicholas A. Zwan
 * 02/14/19
 * This program demos different calculations and uses JOptionPane to display 
   results.
 */
package inclass_10_zwannicholas;

//Import JOptionPane
import javax.swing.JOptionPane;


public class InClass_10_ZwanNicholas {

    public static void main(String[] args) {
       int num1; //Creates variable num2
       int num2; //Creates variable num2
       double radius; //Creates a variable to hold the radius
       double area;   //Creates a variable to hold Area
       String inputString; //Accepts input for user
       
       
      
       //User will enter value of num1
       inputString = 
               JOptionPane.showInputDialog("Enter a value for num1: ");
       num1 = Integer.parseInt(inputString);
       //User will input value of num2
       inputString = 
               JOptionPane.showInputDialog("Enter a value for num2: ");
       num2 = Integer.parseInt(inputString);
       //User will input value of radius
       inputString =
               JOptionPane.showInputDialog("Enter a value for radius");
       radius = Double.parseDouble(inputString);
       
       
       //Generate formulas for calculations
       int addition = num1 + num2;
       int subtraction = num1 - num2;
       int multiplication = num1 * num2;
       int division = num1 / num2;
       int modulus = num1 % num2;
       //Creates formula for area
       //area = Math.PI * (radius * radius);
       area = Math.PI * Math.pow(radius, 2.0);
       
      //Display results
      JOptionPane.showMessageDialog(null,"ADD = " + addition + "\n" +
              "SUB = " + subtraction + "\n" + "MUL = " + multiplication + "\n" +
              "DIV = " + division + "\n" + "MOD = " + modulus + "\n" 
              + "The Radius is " + radius + "\n" + "The area of the circle is " + area);
      
       
      
      
      System.exit(0);
              
       
    
      
       
       
       
    }
    
}

