package inclass_14_zwannicholas;


/**
 * Nicholas A. Zwan
 * 02/28/19
 * InClass14
 * This program will return a letter grade conditional upon user input of an 
 * integer. 
 */
import javax.swing.JOptionPane;
public class InClass_14_ZwanNicholas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int testScore; // Numeric Test Score
        String input; // To hold user's input
        
        //Get the numeric test score
        input = JOptionPane.showInputDialog("Enter your numeric " +
                "testScore and I will tell you the grade: " );
        testScore = Integer.parseInt(input);
        
        //Display the grade.
        if (testScore < 60)
        JOptionPane.showMessageDialog(null, "Your grade is F.");
        else if (testScore < 70)
        JOptionPane.showMessageDialog(null, "Your grade is D.");
        else if (testScore < 80)
        JOptionPane.showMessageDialog(null, "Your grade is C.");
        else if (testScore < 90)
        JOptionPane.showMessageDialog(null, "Your grade is B.");
        else
        JOptionPane.showMessageDialog(null, "Your grade is A.");
        
        System.exit(0);
        
    }
    
} 
